﻿namespace ListyIteratorType
{
    public interface IEnumurable<T>
    {
    }
}