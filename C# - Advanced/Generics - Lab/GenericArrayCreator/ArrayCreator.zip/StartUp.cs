﻿namespace GenericArrayCreator
{
    public class StartUp
    {
        static void Main()
        {
            int[] numbers = ArrayCreator.Create(50, 32);

            Console.WriteLine(string.Join(" ", numbers));
        }
    }
}