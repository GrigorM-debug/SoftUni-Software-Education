﻿namespace P02_FootballBetting.Data.Common
{
    public static class DbConfig
    {
        public const string ConnectionString = @"Server =.; Database=FootballBetting;Integrated Security = True; Encrypt = False;";
    }
}