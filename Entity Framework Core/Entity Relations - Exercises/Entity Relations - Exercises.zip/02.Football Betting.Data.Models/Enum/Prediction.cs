﻿namespace P02_FootballBetting.Data.Models.Enum
{
    public enum Prediction
    {
        Win = 1,
        Lose = 2,
        Draw = 0
    }
}
