﻿using System.Globalization;
using System.Text;
using Invoices.Extensions;
using Medicines.Common;
using Medicines.Data.Models;
using Medicines.Data.Models.Enums;
using Medicines.DataProcessor.ImportDtos;

namespace Medicines.DataProcessor
{
    using Medicines.Data;
    using System.ComponentModel.DataAnnotations;
    using System.Text.RegularExpressions;

    public class Deserializer
    {
        private const string ErrorMessage = "Invalid Data!";
        private const string SuccessfullyImportedPharmacy = "Successfully imported pharmacy - {0} with {1} medicines.";
        private const string SuccessfullyImportedPatient = "Successfully imported patient - {0} with {1} medicines.";

        public static string ImportPatients(MedicinesContext context, string jsonString)
        {
            var patientsDtos = JsonSerializationExtension.DeserializeFromJson<ImportPatientsDto[]>(jsonString);

            var validPationts = new HashSet<Patient>();

            var medicineIds = context.Medicines.Select(x => x.Id).ToArray();

            var sb = new StringBuilder();

            foreach (var patientDto in patientsDtos)
            {
                if (!IsValid(patientDto))
                {
                    sb.AppendLine(ErrorMessage);
                    continue;
                }

                var patient = new Patient()
                {
                    FullName = patientDto.FullName,
                    AgeGroup = (AgeGroup)patientDto.AgeGroup,
                    Gender = (Gender)patientDto.Gender
                };

                foreach (var medicineId in patientDto.Medicines.Distinct())
                {
                    if (!medicineIds.Contains(medicineId))
                    {
                        sb.AppendLine(ErrorMessage); 
                        continue;
                    }

                    var patientMedicine = new PatientMedicine()
                    {
                        Patient = patient,
                        MedicineId = medicineId
                    };

                    if (patient.PatientsMedicines.Contains(patientMedicine))
                    {
                        sb.AppendLine(ErrorMessage);
                        continue;
                    }

                    patient.PatientsMedicines.Add(patientMedicine);
                }

                sb.AppendLine(string.Format(SuccessfullyImportedPatient, patient.FullName,
                    patient.PatientsMedicines.Count));

                validPationts.Add(patient);
            }

            context.AddRange(validPationts);

            context.SaveChanges();

            return sb.ToString().TrimEnd();
        }

        public static string ImportPharmacies(MedicinesContext context, string xmlString)
        {
            var pharmacyDtos = XmlSerializationExtension.DeserializeFromXml<ImportPharmacyDto[]>(xmlString, "Pharmacies");

            var sb = new StringBuilder();

            var validPharmacy = new HashSet<Pharmacy>();

            foreach (var pharmacyDto in pharmacyDtos)
            {
                if (!IsValid(pharmacyDto))
                {
                    sb.AppendLine(ErrorMessage);
                    continue;
                }

                if (string.IsNullOrEmpty(pharmacyDto.Name))
                {
                    sb.AppendLine(ErrorMessage);
                    continue;
                }

                if (!Regex.IsMatch(pharmacyDto.PhoneNumber, ValidationConstants.RegexPattern))
                {
                    sb.AppendLine(ErrorMessage);
                    continue;
                }

                if (!bool.TryParse(pharmacyDto.IsNonStop, out bool isNonStop))
                {
                    sb.AppendLine(ErrorMessage);
                    continue;
                }

                var pharmacy = new Pharmacy()
                {
                    IsNonStop = isNonStop,
                    Name = pharmacyDto.Name,
                    PhoneNumber = pharmacyDto.PhoneNumber,
                };

                foreach (var medicineDto in pharmacyDto.Medicines)
                {
                    if (!IsValid(medicineDto))
                    {
                        sb.AppendLine(ErrorMessage);
                        continue;
                    }

                    if (string.IsNullOrEmpty(medicineDto.Producer) || string.IsNullOrWhiteSpace(medicineDto.Producer))
                    {
                        sb.AppendLine(ErrorMessage); 
                        continue;
                    }

                    if (!decimal.TryParse(medicineDto.Price, out decimal price))
                    {
                        sb.AppendLine(ErrorMessage);
                        continue;
                    }

                    if (!DateTime.TryParseExact(medicineDto.ProductionDate, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime productionDate)
                        || !DateTime.TryParseExact(medicineDto.ExpiryDate, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime expiryDate))
                    {
                        sb.AppendLine(ErrorMessage);
                        continue;
                    }

                    if (productionDate == expiryDate)
                    {
                        sb.AppendLine(ErrorMessage);
                        continue;
                    }

                    if (productionDate > expiryDate)
                    {
                        sb.AppendLine(ErrorMessage);
                        continue;
                    }

                    var medicine = new Medicine()
                    {
                        Name = medicineDto.Name,
                        Price = price,
                        ProductionDate = productionDate,
                        ExpiryDate = expiryDate,
                        Producer = medicineDto.Producer,
                        Category = (Category)medicineDto.Category,
                    };

                    if (pharmacy.Medicines.Any(x => x.Name == medicine.Name && x.Producer == medicine.Producer))
                    {
                        sb.AppendLine(ErrorMessage);
                        continue;
                    }

                    pharmacy.Medicines.Add(medicine);
                }

                validPharmacy.Add(pharmacy);

                sb.AppendLine(string.Format(SuccessfullyImportedPharmacy, pharmacy.Name, pharmacy.Medicines.Count));
            }

            context.Pharmacies.AddRange(validPharmacy);

            context.SaveChanges();

            return sb.ToString().TrimEnd();
        }

        private static bool IsValid(object dto)
        {
            var validationContext = new ValidationContext(dto);
            var validationResult = new List<ValidationResult>();

            return Validator.TryValidateObject(dto, validationContext, validationResult, true);
        }
    }
}
