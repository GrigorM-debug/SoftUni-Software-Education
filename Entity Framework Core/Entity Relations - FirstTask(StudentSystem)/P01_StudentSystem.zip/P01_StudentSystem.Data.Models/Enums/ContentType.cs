﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P01_StudentSystem.Data.Models.Enums
{
    public enum ContentType
    {
        Application,
        Pdf,
        Zip
    }
}
