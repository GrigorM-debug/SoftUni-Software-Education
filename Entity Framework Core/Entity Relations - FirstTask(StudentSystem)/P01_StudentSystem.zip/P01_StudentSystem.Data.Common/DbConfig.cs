﻿namespace P01_StudentSystem.Data.Common
{
    public static class DbConfig
    {
        public const string ConnectionString = @"Server=.;Database=StudentSystem;Integrated Security=True;Encrypt=False;";
    }
}