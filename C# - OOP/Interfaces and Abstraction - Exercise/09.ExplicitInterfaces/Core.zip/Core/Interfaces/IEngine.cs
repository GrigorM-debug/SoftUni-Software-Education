﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExplicitInterfaces.Core.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}
